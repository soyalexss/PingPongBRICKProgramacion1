/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Rectangle;
import javax.swing.JOptionPane;

/**
 *
 * @author Tech Home
 */
public class clsCancha extends Thread{
    // Cancha, color, tablero puntos, pelota, tablita
    private Graphics pintor;
    private Color color;
    // Datos para la tablita
    private int tx,ty,th,tw;
    // pelota
    private clsPelota objPelota;
    
    public clsCancha(Graphics pintor, Color color){
        this.pintor = pintor;
        this.color = color;
        this.th = 10;
        this.tw = 75;
        this.tx = 400-tw/2;
        this.ty = 350;
        this.objPelota = new clsPelota(pintor,color);
        
        
        
       
    }
    boolean ladrillo[] = new boolean[25];
   
    public void iniciarPelota(){
        this.objPelota.start();
        vectortru();
        
    }
    
    public void pausarpelota(){
      
      this.objPelota.suspend();
    
}
    public void continuarpelota(){
         this.objPelota.resume();
    }
   
   
    
    public void detenerpelota(){
        this.objPelota.stop();
        
    }
    
    String punto = "tu puntuacion es " +  0; 
    int p = 0;
    int palto = 0;
    String res = "Tu puntaje mas alto es " + palto;
    
    @Override
    public void run(){
        // Lógica para el juego
        while(true){
        
            DibujarPuntos();
            //DibujarMejorPunto();
           
            if(p < 7){
                nivel1();
                this.pintor.drawString("Nivel 1", 730, 80);
            }
            
            if(p > 6 && p < 22){
                this.pintor.drawString("Nivel 2", 730, 80);
                 nivel2();
             if(p == 7 || p == 8){
                vectortru();
            }
            }
            if(p >= 21 && p < 60  ){
                this.pintor.drawString("Nivel 3", 730, 80);
                nivel3();
                if(p == 21 || p == 22){
                vectortru();
            }
            }
           if(p == 41){
               this.pintor.drawString("GANASTE!! presiona la tecla p para volver a jugar", 250, 190);
               pausarpelota();
           }
               
            
           
            
            Rectangle tabla = new Rectangle(tx,ty,tw,th);
            Rectangle pelota = new Rectangle(objPelota.getPx(),objPelota.getPy(),20,20);
            Rectangle tablaizquierda = new Rectangle(tx,ty,tw/2-30,th);
            Rectangle tabladerecha = new Rectangle(tx+60,ty,tw,th);
            boolean swiz = tablaizquierda.intersects(pelota);
            boolean swder = tabladerecha.intersects(pelota);
            if(swiz){
                this.objPelota.mx = -5;
                this.objPelota.my = -5;
            }
            if(swder){
                this.objPelota.mx = +5;
                this.objPelota.my = -5;
            }
            boolean sw = tabla.intersects(pelota);
            if (objPelota.getPy() > 374 ){
                vectortru();
                p = 0;
                this.pintor.drawString("Perdiste presiona la tecla p para volver a intentar", 250, 190);
                this.punto = "tu puntuacion es " +  p;
                borrarPuntos();
                borrarMejorPunto();
                
                pausarpelota();
                
             
            
                
            }
             if (objPelota.getPy() == 150 ){
                 LimpiarPantalla();
             }
              
            
            if (p > palto){
                    palto = p;
                    System.out.println("nuevo puntaje alto");
                    this.res = "Tu puntaje mas alto es " + palto;
                    borrarMejorPunto();
                }
           
            dibujarTablita();
            
            if (sw) {
                
                objPelota.my = -5;
                //borrarMejorPunto();
                //this.punto = "Tu puntuacion es: " + p;
                //p = p + 1;
                //borrarPuntos();
                LimpiarPantalla();
                
            }
            
            try {
                sleep(objPelota.vel);
            } catch (Exception e) {
                
            }
            
        }
    }
    
     public void LimpiarPantalla(){
        this.pintor.setColor(color);
        this.pintor.fillRect(10, 60, 800,300 );
    }
    
    public void Dibujarperdiste(){
        this.pintor.drawString("Perdiste intentemos de nuevo", 315, 155);
        
    }
    public void borrarperdiste(){
        this.pintor.setColor(color);
        this.pintor.fillRect(300, 140, 200,30 );
    }
    
    public void DibujarMejorPunto(){
        this.pintor.drawString("Mejor puntuacion "+ palto, 660, 80);
        
    }
     public void borrarMejorPunto(){
        this.pintor.setColor(color);
        this.pintor.fillRect(600, 60, 200,30 );
    }
    
    
    public void DibujarPuntos(){
        this.pintor.drawString("Puntos: "+ p, 25, 80);
        
    }
    public void borrarPuntos(){
        this.pintor.setColor(color);
        this.pintor.fillRect(25, 60, 120,30 );
    }
    
    public String mostrarpunto(){
        return this.punto;
    }
    public String mostrarpuntoalto(){
        return res;
    }
    
    public void dibujarTablita(){
        this.pintor.setColor(Color.LIGHT_GRAY);
        this.pintor.fillRoundRect(tx, ty, tw, th, 12, 12);
    }
    
    public void limpiarTablita(){
        this.pintor.setColor(this.color);
        this.pintor.fillRect(tx, ty, tw, th);
    }
    
    public void moverDerechaTablita(){
        if(this.tx < 725){
            dibujarTablita();
            limpiarTablita();
            this.tx = this.tx+10;
            dibujarTablita();
            
        }
        
    }
    
    public void moverIzquierdaTablita(){
        if(this.tx >0){
            dibujarTablita();
            limpiarTablita();
            this.tx = this.tx-10;
            dibujarTablita();
            
        }
        
    }
     private void pintarcuadro(){
        this.pintor.setColor(Color.ORANGE);
        this.pintor.fillRect(1,385, 800, 50);
    }
    public void dibujarLadrillo(int lx , int ly){
        this.pintor.setColor(Color.LIGHT_GRAY);
        this.pintor.fillRect(lx, ly, 70, 25);
    }
    
    public void borrarladrillo(int bx, int by){
        this.pintor.setColor(this.color);
        this.pintor.fillRect(bx, by, 70, 25);
    }
    
    public void vectortru(){
        for (int i = 0; i < 25; i++) {
            ladrillo[i] = true;
            
        }
    }
    
    public void mandarnivel1(){
        p = 0;
    }
    public void mandarnivel2(){
        p = 7;
    }
    public void mandarnivel3(){
        p = 22;
    }   

  
    public void nivel1(){
            Rectangle pelota = new Rectangle(objPelota.getPx(),objPelota.getPy(),20,20);
            
            
            
            if(ladrillo[0]){
            dibujarLadrillo(130, 65);
            }
            Rectangle ladrillo1 = new Rectangle(130,65,70,25);
            boolean sw0 = ladrillo1.intersects(pelota);
                if(ladrillo[0] == false){
                    sw0 = false;
                }
                if(sw0){
                    borrarladrillo(130,65);
                    ladrillo[0] = false;
                    this.objPelota.my = 5;
                   
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            if(ladrillo[1]){    
            dibujarLadrillo(205, 65);}
            Rectangle ladrillo2 = new Rectangle(205,65,70,25);
            boolean sw1 = ladrillo2.intersects(pelota);
            if(ladrillo[1] == false){
                    sw1 = false;
                }
            if(sw1){
                    borrarladrillo(205,65);
                    ladrillo[1] = false;
                    this.objPelota.my = 5;
                                        
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            if(ladrillo[2]){
            dibujarLadrillo(280, 65);}
            Rectangle ladrillo3 = new Rectangle(280,65,70,25);
            boolean sw2 = ladrillo3.intersects(pelota);
            if(ladrillo[2] == false){
                    sw2 = false;
                }
            if(sw2){
                    borrarladrillo(280,65);
                    ladrillo[2] = false;
                    this.objPelota.my = 5;
                                        
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            if(ladrillo[3]){
            dibujarLadrillo(355, 65);}
            Rectangle ladrillo4 = new Rectangle(355,65,70,25);
            boolean sw3 = ladrillo4.intersects(pelota);
            if(ladrillo[3] == false){
                    sw3 = false;
                }
            if(sw3){
                    borrarladrillo(355,65);
                    ladrillo[3] = false;
                    this.objPelota.my = 5;
                                        
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            if(ladrillo[4]){
            dibujarLadrillo(430, 65);}
            Rectangle ladrillo5 = new Rectangle(430,65,70,25);
            boolean sw4 = ladrillo5.intersects(pelota);
            if(ladrillo[4] == false){
                    sw4 = false;
                }
            if(sw4){
                    borrarladrillo(430,65);
                    ladrillo[4] = false;
                    this.objPelota.my = 5;
                                       
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            if(ladrillo[5]){
            dibujarLadrillo(505, 65);}
            Rectangle ladrillo6 = new Rectangle(505,65,70,25);
            boolean sw5 = ladrillo6.intersects(pelota);
            if(ladrillo[5] == false){
                    sw5 = false;
                }
            if(sw5){
                    borrarladrillo(505,65);
                    ladrillo[5] = false;
                    this.objPelota.my = 5;
                                       
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            if(ladrillo[6]){
            dibujarLadrillo(580, 65);}
            Rectangle ladrillo7 = new Rectangle(580,65,70,25);
            boolean sw6 = ladrillo7.intersects(pelota);
            if(ladrillo[6] == false){
                    sw6 = false;
                }
            if(sw6){
                    borrarladrillo(580,65);
                    ladrillo[6] = false;
                    this.objPelota.my = 5;
                                      
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
    }
    public void nivel2(){
            
            Rectangle pelota = new Rectangle(objPelota.getPx(),objPelota.getPy(),20,20);
            
            nivel1();
            
            if(ladrillo[7]){
            dibujarLadrillo(130, 95);
            }
            Rectangle ladrillo1 = new Rectangle(130,95,70,25);
            boolean sw00 = ladrillo1.intersects(pelota);
                if(ladrillo[7] == false){
                    sw00 = false;
                }
                if(sw00){
                    borrarladrillo(130,95);
                    ladrillo[7] = false;
                    this.objPelota.my = 5;
                   
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            if(ladrillo[8]){    
            dibujarLadrillo(205, 95);}
            Rectangle ladrillo2 = new Rectangle(205,95,70,25);
            boolean sw11 = ladrillo2.intersects(pelota);
            if(ladrillo[8] == false){
                    sw11 = false;
                }
            if(sw11){
                    borrarladrillo(205,95);
                    ladrillo[8] = false;
                    this.objPelota.my = 5;
                                        
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            if(ladrillo[9]){
            dibujarLadrillo(280, 95);}
            Rectangle ladrillo3 = new Rectangle(280,95,70,25);
            boolean sw22 = ladrillo3.intersects(pelota);
            if(ladrillo[9] == false){
                    sw22 = false;
                }
            if(sw22){
                    borrarladrillo(280,95);
                    ladrillo[9] = false;
                    this.objPelota.my = 5;
                                        
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            if(ladrillo[10]){
            dibujarLadrillo(355, 95);}
            Rectangle ladrillo4 = new Rectangle(355,95,70,25);
            boolean sw33 = ladrillo4.intersects(pelota);
            if(ladrillo[10] == false){
                    sw33 = false;
                }
            if(sw33){
                    borrarladrillo(355,95);
                    ladrillo[10] = false;
                    this.objPelota.my = 5;
                                        
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            if(ladrillo[11]){
            dibujarLadrillo(430, 95);}
            Rectangle ladrillo5 = new Rectangle(430,95,70,25);
            boolean sw44 = ladrillo5.intersects(pelota);
            if(ladrillo[11] == false){
                    sw44 = false;
                }
            if(sw44){
                    borrarladrillo(430,95);
                    ladrillo[11] = false;
                    this.objPelota.my = 5;
                                       
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            if(ladrillo[12]){
            dibujarLadrillo(505, 95);}
            Rectangle ladrillo6 = new Rectangle(505,95,70,25);
            boolean sw55 = ladrillo6.intersects(pelota);
            if(ladrillo[12] == false){
                    sw55 = false;
                }
            if(sw55){
                    borrarladrillo(505,95);
                    ladrillo[12] = false;
                    this.objPelota.my = 5;
                                       
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            if(ladrillo[13]){
            dibujarLadrillo(580, 95);}
            Rectangle ladrillo7 = new Rectangle(580,95,70,25);
            boolean sw66 = ladrillo7.intersects(pelota);
            if(ladrillo[13] == false){
                    sw66 = false;
                }
            if(sw66){
                    borrarladrillo(580,95);
                    ladrillo[13] = false;
                    this.objPelota.my = 5;
                                      
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
        
        
            
        
          
    }
    public void nivel3(){
            Rectangle pelota = new Rectangle(objPelota.getPx(),objPelota.getPy(),20,20);
        
            nivel2();
           
            
            if(ladrillo[15]){    
            dibujarLadrillo(205, 95+30);}
            Rectangle ladrillo2 = new Rectangle(205,95,70,25);
            boolean sw111 = ladrillo2.intersects(pelota);
            if(ladrillo[15] == false){
                    sw111 = false;
                }
            if(sw111){
                    borrarladrillo(205,95+30);
                    ladrillo[15] = false;
                    this.objPelota.my = 5;
                                        
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            if(ladrillo[16]){
            dibujarLadrillo(280, 95+30);}
            Rectangle ladrillo3 = new Rectangle(280,95+30,70,25);
            boolean sw222 = ladrillo3.intersects(pelota);
            if(ladrillo[16] == false){
                    sw222 = false;
                }
            if(sw222){
                    borrarladrillo(280,95+30);
                    ladrillo[16] = false;
                    this.objPelota.my = 5;
                                        
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            if(ladrillo[17]){
            dibujarLadrillo(355, 95+30);}
            Rectangle ladrillo4 = new Rectangle(355,95+30,70,25);
            boolean sw333 = ladrillo4.intersects(pelota);
            if(ladrillo[17] == false){
                    sw333 = false;
                }
            if(sw333){
                    borrarladrillo(355,95+30);
                    ladrillo[17] = false;
                    this.objPelota.my = 5;
                                        
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            if(ladrillo[18]){
            dibujarLadrillo(430, 95+30);}
            Rectangle ladrillo5 = new Rectangle(430,95+30,70,25);
            boolean sw444 = ladrillo5.intersects(pelota);
            if(ladrillo[18] == false){
                    sw444 = false;
                }
            if(sw444){
                    borrarladrillo(430,95+30);
                    ladrillo[18] = false;
                    this.objPelota.my = 5;
                                       
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            if(ladrillo[19]){
            dibujarLadrillo(505, 95+30);}
            Rectangle ladrillo6 = new Rectangle(505,95+30,70,25);
            boolean sw555 = ladrillo6.intersects(pelota);
            if(ladrillo[19] == false){
                    sw555 = false;
                }
            if(sw555){
                    borrarladrillo(505,95+30);
                    ladrillo[19] = false;
                    this.objPelota.my = 5;
                                       
                    this.punto = "Tu puntuacion es: " + p;
                    p = p + 1;
                    borrarPuntos();
                }
            
            }
}
