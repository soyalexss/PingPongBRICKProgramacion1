/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Tech Home
 */
public class clsPelota extends Thread{
    
 
    private int px,py,w,h;
    private Graphics pintor;
    private Color color;
    public clsPelota(Graphics pintor, Color color){
        this.w = 20;
        this.h = 20;
        this.px = (int)(Math.random()* 800)-30;
        this.py = 130;
        this.pintor = pintor;
        this.color = color;
    }
    int my = 5;
    int mx = 3;
    int vel = 40;
    @Override
    public void run(){
        while(true){
            // Aqui hay que programar la direccion de la pelota..
           
            pintarP();
            borrarP();
            
            this.py = this.py + this.my;
            this.px = this.px + this.mx;
            
            pintarP();
           if(this.py < 75){
               this.my = +5;
           }
            
           if (this.px > 780){
                
               this.mx = -3;
                //this.setPx(0);
                
            }
           if (this.px < 0){
                
               this.mx = +3;
           pintarP();
           borrarP();     
            }
            
            if(this.py > 375){
                borrarP(); 
                this.px = (int)(Math.random()*800)-30;
                this.py = 95;
                
            }
            try {
                dormir(vel);

            } catch (Exception e) {
                
            }
          
           
           
        }
    }
    
   // public void Stop(){
        
   
//} 
    
    public void dormir(int vel) throws InterruptedException{
        sleep(vel);
    }
   
    
    
    private void pintarP(){
        this.pintor.setColor(Color.ORANGE);
        this.pintor.fillOval(px, py, w, h);
    }
    public void borrarP(){
        this.pintor.setColor(this.color);
        this.pintor.fillOval(px, py, w, h);
    }
    
    public int getPx() {
        return px;
    }

    public void setPx(int px) {
        this.px = px;
    }

    public int getPy() {
        return py;
    }

    public void setPy(int py) {
        this.py = py;
    }

    public int getW() {
        return w;
    }

    public void setW(int w) {
        this.w = w;
    }

    public int getH() {
        return h;
    }

    public void setH(int h) {
        this.h = h;
    }
   
    
    
}
